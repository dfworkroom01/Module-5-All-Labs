const express = require('express');
const Calculator = require('./library/Calculator');
const { logMessage } = require('./library/Logger');
const app = express();

const handleError = (res, message) => {
  return res.status(400).json({ error: message });
};

app.get('/calculator/add', (req, res) => {
  const num1 = parseFloat(req.query.num1);
  const num2 = parseFloat(req.query.num2);

  if (isNaN(num1) || isNaN(num2)) {
    return handleError(res, 'Invalid input numbers');
  }

  const { id, result } = Calculator.add(num1, num2); // ID is destructured
  console.log('Calculator Output:', { id, result }); // Log output to verify
  logMessage(id, 'Add', result);
  res.json({ id, result });
});


// Other operations

app.get('/calculator/subtract', (req, res) => {
  const num1 = parseFloat(req.query.num1);
  const num2 = parseFloat(req.query.num2);

  if (isNaN(num1) || isNaN(num2)) {
    return handleError(res, 'Invalid input numbers');
  }

  const { id, result } = Calculator.subtract(num1, num2);
  logMessage(id, 'Subtract', result);
  res.json({ id, result });
});

app.get('/calculator/multiply', (req, res) => {
  const num1 = parseFloat(req.query.num1);
  const num2 = parseFloat(req.query.num2);

  if (isNaN(num1) || isNaN(num2)) {
    return handleError(res, 'Invalid input numbers');
  }

  const { id, result } = Calculator.multiply(num1, num2);
  console.log('Calculator Output:', { id, result }); // Log output to verify
  logMessage(id, 'Multiply', result);
  res.json({ id, result });
});

app.get('/calculator/divide', (req, res) => {
  const num1 = parseFloat(req.query.num1);
  const num2 = parseFloat(req.query.num2);

  if (isNaN(num1) || isNaN(num2)) {
    return handleError(res, 'Invalid input numbers');
  }

  const { id, result } = Calculator.divide(num1, num2);
  console.log('Calculator Output:', { id, result }); // Log output to verify
  logMessage(id, 'Divide', result);
  res.json({ id, result });
});

module.exports = app;
