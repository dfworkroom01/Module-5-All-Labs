const logMessage = (id, operation, result) => {
    console.log(`ID: ${id} | Operation: ${operation} | Result: ${result}`);
  };
  
  module.exports = { logMessage };

 