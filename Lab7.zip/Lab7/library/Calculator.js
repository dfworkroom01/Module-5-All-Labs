const { v4: uuidv4 } = require('uuid'); // Import UUID v4

const generateId = () => {
  return uuidv4(); // Generate a unique ID
};

const Calculator = {
  add: (num1, num2) => {
    const result = num1 + num2;
    return { id: generateId(), result };
  },
  subtract: (num1, num2) => {
    const result = num1 - num2;
    return { id: generateId(), result };
  },
  multiply: (num1, num2) => {
    const result = num1 * num2;
    return { id: generateId(), result };
  },
  divide: (num1, num2) => {
    if (num2 === 0) {
      return { id: generateId(), result: 'Cannot divide by zero' };
    }
    const result = num1 / num2;
    return { id: generateId(), result };
  }
};

module.exports = Calculator;