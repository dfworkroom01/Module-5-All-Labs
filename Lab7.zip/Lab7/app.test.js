const request = require('supertest');
const app = require('./app');

describe('Calculator Routes', () => {
  let number1;
  let number2;

  beforeEach(() => {
    number1 = Math.floor(Math.random() * 1_000_000);
    number2 = Math.floor(Math.random() * 1_000_000);
  });

  test('GET /calculator/add => sum of numbers', () => {
    return request(app)
      .get(`/calculator/add?num1=${number1}&num2=${number2}`)
      .expect('Content-Type', /json/)
      .expect(200)
      .then((response) => {
        expect(response.body.result).toEqual(number1 + number2);
        expect(response.body).toHaveProperty('id');
      });
  });

  test('GET /calculator/subtract => difference of numbers', () => {
    return request(app)
      .get(`/calculator/subtract?num1=${number1}&num2=${number2}`)
      .expect('Content-Type', /json/)
      .expect(200)
      .then((response) => {
        expect(response.body.result).toEqual(number1 - number2);
        expect(response.body).toHaveProperty('id');
      });
  });

  test('GET /calculator/multiply => product of numbers', () => {
    return request(app)
      .get(`/calculator/multiply?num1=${number1}&num2=${number2}`)
      .expect('Content-Type', /json/)
      .expect(200)
      .then((response) => {
        expect(response.body.result).toEqual(number1 * number2);
        expect(response.body).toHaveProperty('id');
      });
  });

  test('GET /calculator/divide => quotient of numbers', () => {
    return request(app)
      .get(`/calculator/divide?num1=${number1}&num2=${number2}`)
      .expect('Content-Type', /json/)
      .expect(200)
      .then((response) => {
        if (number2 !== 0) {
          expect(response.body.result).toEqual(number1 / number2);
        } else {
          expect(response.body.result).toEqual('Cannot divide by zero');
        }
        expect(response.body).toHaveProperty('id');
      });
  });

  test('GET /calculator/divide with zero => division by zero error', () => {
    number2 = 0;

    return request(app)
      .get(`/calculator/divide?num1=${number1}&num2=${number2}`)
      .expect('Content-Type', /json/)
      .expect(200)
      .then((response) => {
        expect(response.body.result).toEqual('Cannot divide by zero');
        expect(response.body).toHaveProperty('id');
      });
  });
});
