document.addEventListener('DOMContentLoaded', () => {
    const resultDiv = document.getElementById('result');
  
    const calculate = async (operation) => {
      const num1 = document.getElementById('num1').value;
      const num2 = document.getElementById('num2').value;
  
      try {
        const response = await fetch(`/api/calculator/${operation}?num1=${num1}&num2=${num2}`);
  
        // Log the response for debugging
        console.log('Response:', response);
  
        // Check if the response is not OK
        if (!response.ok) {
          const errorData = await response.text(); // Get the raw response text
          resultDiv.innerHTML = `Error: ${errorData}`;
          return;
        }
  
        const data = await response.json(); // Parse the response as JSON
        resultDiv.innerHTML = `ID: ${data.id} | Result: ${data.result}`;
      } catch (error) {
        resultDiv.innerHTML = `Error: Unable to parse response. ${error.message}`;
        console.error('Fetch error:', error);
      }
    };
  
    document.getElementById('add').onclick = () => calculate('add');
    document.getElementById('subtract').onclick = () => calculate('subtract');
    document.getElementById('multiply').onclick = () => calculate('multiply');
    document.getElementById('divide').onclick = () => calculate('divide');
  });
  