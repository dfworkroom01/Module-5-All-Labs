async function calculate(operation) {
    const num1 = document.getElementById('num1').value;
    const num2 = document.getElementById('num2').value;

    const response = await fetch(`/api/calculator/${operation}?num1=${num1}&num2=${num2}`);

    if (!response.ok) {
        const errorData = await response.json();
        document.getElementById('result').innerText = `Error: ${errorData.error}`;
    } else {
        const data = await response.json();
        document.getElementById('result').innerText = `Result: ${data.result}`;
    }
}