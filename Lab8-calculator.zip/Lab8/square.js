function square(a) {
    return a * a;
  }
  module.exports = { square };