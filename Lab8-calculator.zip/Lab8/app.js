const express = require('express');
const Calculator = require('./library/Calculator');
const { logMessage } = require('./library/Logger');
const swaggerUi = require('swagger-ui-express');
const swaggerJsDoc = require('swagger-jsdoc');
const app = express();

// Swagger options
const swaggerOptions = {
  definition: {
    openapi: "3.0.0",
    info: {
      title: "Calculator API",
      version: "1.0.0",
      description: "A simple calculator API to perform basic operations",
    },
    servers: [
      {
        url: "http://localhost:3000",
      },
    ],
  },
  apis: ["./app.js"], // Path to the API docs
};

// Initialize Swagger
const swaggerDocs = swaggerJsDoc(swaggerOptions);
app.use("/api-docs", swaggerUi.serve, swaggerUi.setup(swaggerDocs));

// Calculator routes
/**
 * @swagger
 * /calculator/add:
 *   get:
 *     summary: Add two numbers
 *     parameters:
 *       - in: query
 *         name: num1
 *         required: true
 *         schema:
 *           type: number
 *       - in: query
 *         name: num2
 *         required: true
 *         schema:
 *           type: number
 *     responses:
 *       200:
 *         description: Successful operation
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 id:
 *                   type: string
 *                 result:
 *                   type: number
 *       400:
 *         description: Invalid input
 */
app.get("/calculator/add", (req, res) => {
  const num1 = parseFloat(req.query.num1);
  const num2 = parseFloat(req.query.num2);

  if (isNaN(num1) || isNaN(num2)) {
    return res.status(400).json({ error: "Invalid input numbers" });
  }

  const output = Calculator.add(num1, num2);
  logMessage(output.id, "Add", output.result);
  res.json(output);
});

/**
 * @swagger
 * /calculator/subtract:
 *   get:
 *     summary: Subtract two numbers
 *     parameters:
 *       - in: query
 *         name: num1
 *         required: true
 *         schema:
 *           type: number
 *       - in: query
 *         name: num2
 *         required: true
 *         schema:
 *           type: number
 *     responses:
 *       200:
 *         description: Successful operation
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 id:
 *                   type: string
 *                 result:
 *                   type: number
 *       400:
 *         description: Invalid input
 */
app.get("/calculator/subtract", (req, res) => {
  const num1 = parseFloat(req.query.num1);
  const num2 = parseFloat(req.query.num2);

  if (isNaN(num1) || isNaN(num2)) {
    return res.status(400).json({ error: "Invalid input numbers" });
  }

  const output = Calculator.subtract(num1, num2);
  logMessage(output.id, "Subtract", output.result);
  res.json(output);
});

/**
 * @swagger
 * /calculator/multiply:
 *   get:
 *     summary: Multiply two numbers
 *     parameters:
 *       - in: query
 *         name: num1
 *         required: true
 *         schema:
 *           type: number
 *       - in: query
 *         name: num2
 *         required: true
 *         schema:
 *           type: number
 *     responses:
 *       200:
 *         description: Successful operation
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 id:
 *                   type: string
 *                 result:
 *                   type: number
 *       400:
 *         description: Invalid input
 */
app.get("/calculator/multiply", (req, res) => {
  const num1 = parseFloat(req.query.num1);
  const num2 = parseFloat(req.query.num2);

  if (isNaN(num1) || isNaN(num2)) {
    return res.status(400).json({ error: "Invalid input numbers" });
  }

  const output = Calculator.multiply(num1, num2);
  logMessage(output.id, "Multiply", output.result);
  res.json(output);
});

/**
 * @swagger
 * /calculator/divide:
 *   get:
 *     summary: Divide two numbers
 *     parameters:
 *       - in: query
 *         name: num1
 *         required: true
 *         schema:
 *           type: number
 *       - in: query
 *         name: num2
 *         required: true
 *         schema:
 *           type: number
 *     responses:
 *       200:
 *         description: Successful operation
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 id:
 *                   type: string
 *                 result:
 *                   type: number
 *       400:
 *         description: Invalid input
 */
app.get("/calculator/divide", (req, res) => {
  const num1 = parseFloat(req.query.num1);
  const num2 = parseFloat(req.query.num2);

  if (isNaN(num1) || isNaN(num2)) {
    return res.status(400).json({ error: "Invalid input numbers" });
  }

  const output = Calculator.divide(num1, num2);
  logMessage(output.id, "Divide", output.result);
  res.json(output);
});

// Start the server
const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`Server is running on http://localhost:${PORT}`);
});

module.exports = app;
