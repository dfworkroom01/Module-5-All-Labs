const express = require('express');
const calculatorRoutes = require('./calculatorRoutes');

const app = express();
const PORT = 3000;

// Middleware to parse JSON requests
app.use(express.json());

// Serve static files from the "public" directory
app.use(express.static('public'));

// Use the calculator routes
app.use('/api/calculator', calculatorRoutes);

app.listen(PORT, () => {
    console.log(`Calculator app is running on http://localhost:${PORT}`);
});