async function calculate(operation) {
    const num1 = document.getElementById('num1').value;
    const num2 = document.getElementById('num2').value;

    const response = await fetch(`/api/calculator/${operation}?num1=${num1}&num2=${num2}`);
    const data = await response.json();

    const resultDiv = document.getElementById('result');
    
    if (response.ok) {
        resultDiv.innerText = `Result: ${data.result}`;
    } else {
        resultDiv.innerText = `Error: ${data.error}`;
    }
}