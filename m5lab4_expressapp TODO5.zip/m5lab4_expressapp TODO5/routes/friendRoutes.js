const express = require("express");
const router = express.Router();
const friends = require("../models/friends");

// Get all friends or filter by gender or starting letter
router.get("/", (req, res) => {
  const { gender, letter } = req.query;
  let matchingFriends = [...friends];

  if (gender) {
    matchingFriends = matchingFriends.filter(friend => friend.gender === gender);
  }

  if (letter) {
    matchingFriends = matchingFriends.filter(friend => friend.name.startsWith(letter));
  }

  res.status(200).json(matchingFriends);
});

// Get a single friend by ID
router.get("/:id", (req, res) => {
  const friendId = parseInt(req.params.id, 10);
  const friend = friends.find(friend => friend.id === friendId);

  if (friend) {
    res.json(friend);
  } else {
    res.status(404).json({ error: "Friend not found." });
  }
});

// Add other routes (POST, PUT, DELETE) as necessary...

module.exports = router;
