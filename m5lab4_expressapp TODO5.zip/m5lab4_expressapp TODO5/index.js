const express = require("express");
const helmet = require("helmet");
const friendRoutes = require('./routes/friendRoutes');

const app = express();
const port = 3000;

// Use helmet for security headers
app.use(helmet());

// Customize CSP (if needed)
app.use(helmet.contentSecurityPolicy({
  directives: {
    defaultSrc: ["'self'"],
    imgSrc: ["'self'"],
    scriptSrc: ["'self'"],
    styleSrc: ["'self'"],
  }
}));

app.use(express.json());
app.use('/', express.static('public'));
app.use('/friends', friendRoutes);

// Simple root route
app.get('/', (req, res) => {
  res.send('Welcome to the Friends API!');
});

// Error handling middleware
app.use((err, req, res, next) => {
  console.error(err.stack);
  res.status(500).json({ error: 'Something went wrong!' });
});

// Start the server
app.listen(port, () => {
  console.log(`Example app listening at http://localhost:${port}`);
});
