const express = require("express"); 
const friendRoutes = require('./routes/friendRoutes');

const app = express(); // create a new app
const port = 4000; // change this to run the app on a different port - usually a 4 digit number

// parse requests of content-type - application/json (needed for POST and PUT requests using req.body)
app.use(express.json());

// Serve static files from the 'public' directory
app.use('/', express.static('public'));

// Use friend routes
app.use('/friends', friendRoutes);

// Error handling middleware
app.use((err, req, res, next) => {
  console.error(err.stack);
  res.status(500).json({ error: 'Something went wrong!' });
});

// Starts the backend app on the given port
app.listen(port, () => {
  console.log(`Example app listening at http://localhost:${port}`);
});

