const express = require("express");
const router = express.Router();
const friends = require("../models/friends");

// 1. Filter endpoint to include 'letter' query parameter
router.get("/filter", (req, res) => {
  console.log(req.query);
  let filterGender = req.query.gender;
  let filterLetter = req.query.letter;
  let matchingFriends = [...friends];

  if (filterGender) {
    matchingFriends = matchingFriends.filter(
      (friend) => friend.gender === filterGender
    );
  }

  if (filterLetter) {
    matchingFriends = matchingFriends.filter(
      (friend) => friend.name.startsWith(filterLetter)
    );
  }

  if (matchingFriends.length > 0) {
    res.status(200).json(matchingFriends);
  } else {
    res.status(404).json({ error: "No friends matching your request." });
  }
});

// 2. Modify the 'info' route to return specific header information
router.get("/info", (req, res) => {
  const { 'user-agent': userAgent, 'content-type': contentType, accept } = req.headers;
  res.json({ userAgent, contentType, accept });
});

// 3. Dynamic GET route to return a single friend object by ID
router.get("/:id", (req, res) => {
  console.log(req.params);
  let friendId = parseInt(req.params.id, 10); // Convert ID to an integer
  const friend = friends.find(friend => friend.id === friendId);

  if (friend) {
    res.json(friend);
  } else {
    res.status(404).json({ error: "Friend cannot be found." });
  }
});

// 4. Complete the PUT route to update existing friend data
router.put("/:id", (req, res) => {
  let friendId = parseInt(req.params.id, 10);
  let updatedFriend = req.body;

  let index = friends.findIndex(friend => friend.id === friendId);
  if (index !== -1) {
    // Update the friend object
    friends[index] = { ...friends[index], ...updatedFriend };
    res.json(friends[index]);
  } else {
    res.status(404).json({ error: "Friend cannot be found." });
  }
});

// a POST request to add a new friend
router.post("/", (req, res) => {
  let newFriend = req.body;
  console.log(newFriend);

  if (!newFriend.name || !newFriend.gender) {
    res.status(400).json({ error: "Friend data must contain a name and gender" });
    return;
  }
  
  // Generate an ID if one is not present
  if (!newFriend.id) {
    newFriend.id = friends.length ? friends[friends.length - 1].id + 1 : 1;
  }

  friends.push(newFriend);
  res.status(201).json(newFriend);
});

module.exports = router;
