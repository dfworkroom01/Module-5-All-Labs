// product.test.js
const request = require('supertest');
const express = require('express');
const productRoutes = require('../routes/productRoutes');

const app = express();
app.use(express.json()); // Middleware to parse JSON
app.use('/api/products', productRoutes);

describe('GET /api/products', () => {
    it('should return 200 and a list of products', async () => {
        const res = await request(app).get('/api/products'); // Correct endpoint
        expect(res.statusCode).toEqual(200);
        expect(Array.isArray(res.body)).toBeTruthy();
    });
});
