const express = require('express');
const { getProducts } = require('../controllers/productController');

const router = express.Router();

/**
 * @swagger
 * /:
 *   get:
 *     summary: Get all products
 *     responses:
 *       200:
 *         description: A list of products
 */
router.get('/', getProducts);

module.exports = router;
