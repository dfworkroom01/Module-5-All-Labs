const swaggerJSDoc = require('swagger-jsdoc');

const swaggerDefinition = {
    openapi: '3.0.0',
    info: {
        title: 'Fake eCommerce Store API',
        version: '1.0.0',
        description: 'API for Fake eCommerce Store',
    },
    servers: [
        {
            url: 'http://localhost:3000/api/products',
        },
    ],
};

const options = {
    swaggerDefinition,
    apis: ['./src/routes/*.js'], // Path to the API docs
};

const swaggerSpec = swaggerJSDoc(options);

module.exports = swaggerSpec;
