const express = require("express");
const app1 = express();
const app2 = express();

const port1 = 2000;
const port2 = 3000;


app1.get("/", (req, res) => {
  res.send("Hi I am app1!");
});

app2.get('/test', (req, res) => {
    res.send('Hi I am app2')
  })

app1.listen(port1, () => {
  console.log(`Lab app1 listening 
at http://localhost:${port1}`);
});

app2.listen(port2, () => {
    console.log(`Lab app2 listening 
  at http://localhost:${port2}`);
  });